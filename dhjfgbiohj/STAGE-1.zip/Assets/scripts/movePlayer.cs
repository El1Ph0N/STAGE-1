﻿using UnityEditor.Animations;
using UnityEngine;

public class movePlayer : MonoBehaviour
{
    private Rigidbody rb;
    public float speed = 0.5f;
    private Vector3 moveVector;
    public float jump_forse = 0f;
    bool isGrounded = true;
    public float spdash = 10f;
    [SerializeField] Animator _animator;

    float _rotationSpeed = 6f;

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
    }

    private void Update()
    {
        float horizontal = Input.GetAxis("Horizontal");
        if (Input.GetKeyDown(KeyCode.Space))
        {
            Vector3 DD = transform.TransformDirection(Vector3.down);
            RaycastHit hit;
            if (Physics.Raycast(transform.position, DD, 1.5f))
            {
                rb.AddForce(transform.up * jump_forse, ForceMode.VelocityChange);
            }

        }
        if (Input.GetKeyDown(KeyCode.LeftShift) && horizontal != 0)
        {
            rb.AddForce(moveVector * spdash, ForceMode.Impulse);
            _animator.SetBool("run", true);
            //FIstcol.SetActive(false);
            //Secondcol.SetActive(true);


        }
        if (Input.GetKeyUp(KeyCode.LeftShift))
        {
            _animator.SetBool("run", false);
        }

            if (horizontal > 0f)
        {
            transform.rotation = Quaternion.Lerp(transform.rotation, Quaternion.Euler(0f, 0f, 0f), _rotationSpeed * Time.deltaTime);
        }
        else if (horizontal < 0f)
        {
            transform.rotation = Quaternion.Lerp(transform.rotation, Quaternion.Euler(0f, -180f, 0f), _rotationSpeed * Time.deltaTime);
        }

    }
    void FixedUpdate()
    {
        moveVector.x = Input.GetAxis("Horizontal");
        rb.MovePosition(rb.position + moveVector * speed * Time.fixedDeltaTime);




        if (moveVector.x != 0f)
        {
            _animator.SetBool("walk", true);
        }
        else if (moveVector.x == 0f)
        {
            _animator.SetBool("walk", false);
        }

    }
}